
package principaldeacuario;

public class EspecieDuplicadaException extends Exception{
    private static final String MESSAGE = "Ya esta registrada esa especie";
    
    public EspecieDuplicadaException(){
        this(MESSAGE);
    }
    
    public EspecieDuplicadaException(String mensaje){
        super(mensaje);
    }
    
}
