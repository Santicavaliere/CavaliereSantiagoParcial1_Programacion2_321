package principaldeacuario;

public abstract class EspecieMarina implements Vivible {

    private String nombre;
    private String tanqueDeUbicacion;
    private final TipoDeAgua tipo;

    public EspecieMarina(String nombre, String tanqueDeUbicacion, TipoDeAgua tipo) {
        this.nombre = nombre;
        this.tanqueDeUbicacion = tanqueDeUbicacion;
        this.tipo = tipo;
    }

    public TipoDeAgua getTipo() {
        return tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTanqueDeUbicacion() {
        return tanqueDeUbicacion;
    }

    @Override
    public void respirar() {
        System.out.println("Respira bajo el agua.");
    }

    @Override
    public void reproducirse() {
        System.out.println("Se reproduce.");
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ". Tanque: " + tanqueDeUbicacion + ". Tipo de agua: " + tipo;
    }

}
