package principaldeacuario;

import java.util.ArrayList;

public class Acuario {

    private ArrayList<EspecieMarina> especies;

    public Acuario(ArrayList<EspecieMarina> especies) {
        this.especies = especies;
    }

    public Acuario() {
        this.especies = new ArrayList<>();
    }

    public void agregarEspecie(EspecieMarina especie) throws EspecieDuplicadaException {
    for (EspecieMarina e : especies) {
        if (e.getNombre().equalsIgnoreCase(especie.getNombre()) &&
            e.getTanqueDeUbicacion().equalsIgnoreCase(especie.getTanqueDeUbicacion())) {
            System.out.println("Ya existe una especie con el nombre "
                    + especie.getNombre() + " en el tanque " + especie.getTanqueDeUbicacion());
            return;
        }
    }
    especies.add(especie);
    }

    public void moverEspecies() {
        for (EspecieMarina especie : especies) {
            if (especie instanceof Movible movible) {
                movible.mover();
            } else {
                System.out.println("La especie " + especie.getNombre() + " no puede moverse.");
            }
        }
    }

    public void realizarFuncionesBiologicas() {
        for (EspecieMarina especie : especies) {
            especie.respirar();

            if (especie instanceof Alimentable alimentable) {
                alimentable.alimentar();
            }
        }
    }

    public void mostrarEspecies() {
        for (EspecieMarina especie : especies) {
            System.out.println("-------------------------------------------");
            System.out.println(especie);
        }
    }

    public ArrayList<EspecieMarina> filtrarPorTipoDeAgua(TipoDeAgua tipo) {
        ArrayList<EspecieMarina> filtradas = new ArrayList<>();

        for (EspecieMarina especie : especies) {
            if (especie.getTipo() == tipo) {
                filtradas.add(especie);
            }
        }
        System.out.println("Especies de tipo de agua: " + tipo);
        
        for (EspecieMarina especie : filtradas) {
            System.out.println("La especie: " + especie.getNombre() + " (" + especie.getClass().getSimpleName() + ")");
        }

        return filtradas;
    }

}
