package principaldeacuario;

public enum TipoDeAgua {
    AGUASALADA,
    AGUADULCE
    
}
