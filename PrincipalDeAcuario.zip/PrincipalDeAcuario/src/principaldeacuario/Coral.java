package principaldeacuario;

public class Coral extends EspecieMarina {

    private double profundidadIdeal;

    public Coral(double profundidadIdeal, String nombre, String tanqueDeUbicacion, TipoDeAgua tipo) {
        super(nombre, tanqueDeUbicacion, tipo);
        this.profundidadIdeal = profundidadIdeal;
    }

    public double getProfundidadIdeal() {
        return profundidadIdeal;
    }

    @Override
    public String toString() {
        return super.toString() + ". Tipo: Coral" + ". Profundidad ideal: " + profundidadIdeal + " metros.";
    }

}
