package principaldeacuario;


public interface Alimentable {
    void alimentar();
    
}
