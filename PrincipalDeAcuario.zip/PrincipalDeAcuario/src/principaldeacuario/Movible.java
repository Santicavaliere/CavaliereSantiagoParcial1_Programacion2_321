
package principaldeacuario;

public interface Movible {
    void mover();
    
}
