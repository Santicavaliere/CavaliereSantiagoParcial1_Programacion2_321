package principaldeacuario;

public class Molusco extends EspecieMarina implements Alimentable, Movible {

    private String tipoDeConcha;

    public Molusco(String tipoDeConcha, String nombre, String tanqueDeUbicacion, TipoDeAgua tipo) {
        super(nombre, tanqueDeUbicacion, tipo);
        this.tipoDeConcha = tipoDeConcha;
    }

    public String getTipoDeConcha() {
        return tipoDeConcha;
    }

    @Override
    public void alimentar() {
        System.out.println("Los moluscos estan siendo alimentados.");

    }

    @Override
    public void mover() {
        System.out.println("Los moluscos estan siendo movidos.");
    }

    @Override
    public String toString() {
        return super.toString() + ". Tipo: Molusco" + ". Tipo de concha: " + tipoDeConcha;
    }

}
