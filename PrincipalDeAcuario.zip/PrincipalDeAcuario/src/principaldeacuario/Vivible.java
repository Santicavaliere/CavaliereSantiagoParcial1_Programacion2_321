
package principaldeacuario;


public interface Vivible {
    void respirar();
    void reproducirse();
    
}
