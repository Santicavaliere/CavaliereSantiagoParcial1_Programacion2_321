package principaldeacuario;

import java.util.ArrayList;

public class PrincipalDeAcuario {

    public static void main(String[] args) {
        Acuario acuario = new Acuario(new ArrayList<>());
        try {
            EspecieMarina pez1 = new Pez(15, "Pez Payaso", "T1", TipoDeAgua.AGUASALADA);
            EspecieMarina molusco1 = new Molusco("Bivalva", "Almeja Gigante", "T2", TipoDeAgua.AGUASALADA);
            EspecieMarina coral1 = new Coral(10, "Coral Cerebro", "T3", TipoDeAgua.AGUASALADA);

            acuario.agregarEspecie(pez1);
            acuario.agregarEspecie(molusco1);
            acuario.agregarEspecie(coral1);

            EspecieMarina pezDuplicado = new Pez(12, "Pez Payaso", "T1", TipoDeAgua.AGUASALADA);
            acuario.agregarEspecie(pezDuplicado); 

        } catch (EspecieDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println("\n--------------------------------------------------");
        acuario.mostrarEspecies();
        System.out.println("\n--------------------------------------------------");
        acuario.moverEspecies();
        System.out.println("\n--------------------------------------------------");
        acuario.realizarFuncionesBiologicas();
        System.out.println("\n--------------------------------------------------");
        acuario.filtrarPorTipoDeAgua(TipoDeAgua.AGUASALADA);
    }

}
