package principaldeacuario;

public class Pez extends EspecieMarina implements Alimentable, Movible {

    private double longitudMaxima;

    public Pez(double longitudMaxima, String nombre, String tanqueDeUbicacion, TipoDeAgua tipo) {
        super(nombre, tanqueDeUbicacion, tipo);
        this.longitudMaxima = longitudMaxima;
    }

    public double getLongitudMaxima() {
        return longitudMaxima;
    }

    @Override
    public void alimentar() {
        System.out.println("Los peces estan siendo alimentados.");
    }

    @Override
    public void mover() {
        System.out.println("Los peces estan siendo movidos.");
    }

    @Override
    public String toString() {
        return super.toString() + ". Tipo: Pez" + ". Longitud máxima: " + longitudMaxima + " cm";
    }
}
